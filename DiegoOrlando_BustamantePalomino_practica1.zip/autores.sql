CREATE TABLE IF NOT EXISTS autores(
    autor_id serial primary key,
    nombre varchar(100) not null
);


