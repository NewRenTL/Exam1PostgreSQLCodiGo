CREATE TABLE IF NOT EXISTS categorias(
    categoria_id serial primary key,
    nombre varchar(100) not null
);




