
CREATE TABLE IF NOT EXISTS lectores(
    lector_id serial primary key,
    nombre varchar(100)
);