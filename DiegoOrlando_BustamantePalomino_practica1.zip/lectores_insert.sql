insert into lectores (nombre) values ('Whitney Curthoys');
insert into lectores (nombre) values ('Kissiah Klaes');
insert into lectores (nombre) values ('Alica Maides');
insert into lectores (nombre) values ('Ash Spain');
insert into lectores (nombre) values ('Hamel Fairburn');
insert into lectores (nombre) values ('Benedict Toyer');
insert into lectores (nombre) values ('Nikolia Brose');
insert into lectores (nombre) values ('Brooke Burren');
insert into lectores (nombre) values ('Marjy Harrismith');
insert into lectores (nombre) values ('Mil Hatliffe');

select * from lectores;