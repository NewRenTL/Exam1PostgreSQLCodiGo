CREATE TABLE IF NOT EXISTS libros(
    ISBN varchar primary key not null,
    Titulo varchar not null
);


