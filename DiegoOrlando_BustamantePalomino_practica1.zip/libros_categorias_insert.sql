--select * from libros;
--select * from categorias;
---select * from libros_categorias;

insert into libros_categorias (isbn, categoria_id) values ('60505-2869', 5);
insert into libros_categorias (isbn, categoria_id) values ('61442-201', 3);
insert into libros_categorias (isbn, categoria_id) values ('49348-845', 3);
insert into libros_categorias (isbn, categoria_id) values ('0115-1331', 5);
insert into libros_categorias (isbn, categoria_id) values ('52125-648', 9);
insert into libros_categorias (isbn, categoria_id) values ('36987-2550', 8);
insert into libros_categorias (isbn, categoria_id) values ('10733-357', 9);
insert into libros_categorias (isbn, categoria_id) values ('59779-572', 2);
insert into libros_categorias (isbn, categoria_id) values ('49967-166', 1);
insert into libros_categorias (isbn, categoria_id) values ('66184-490', 9);