insert into libros (ISBN, titulo) values ('60505-2869', 'Lawnmower Man 2: Beyond Cyberspace');
insert into libros (ISBN, titulo) values ('61442-201', 'Cool, Dry Place, A');
insert into libros (ISBN, titulo) values ('49348-845', 'Program, The');
insert into libros (ISBN, titulo) values ('0115-1331', 'Adam & Paul');
insert into libros (ISBN, titulo) values ('52125-648', 'Mickey Blue Eyes');
insert into libros (ISBN, titulo) values ('36987-2550', 'Torremolinos 73');
insert into libros (ISBN, titulo) values ('10733-357', 'Halo Legends');
insert into libros (ISBN, titulo) values ('59779-572', 'Days Between, The (In den Tag hinein)');
insert into libros (ISBN, titulo) values ('49967-166', 'Grown Ups');
insert into libros (ISBN, titulo) values ('66184-490', 'Marty');

select * from libros;