insert into prestamos (fecha_prestamo, fecha_devolucion_esperada, isbn, lector_id) values ('2023-01-31 07:27:54', '2023-04-15 22:22:36', '60505-2869', 5);
insert into prestamos (fecha_prestamo, fecha_devolucion_esperada, isbn, lector_id) values ('2023-02-03 05:21:25', '2023-03-16 02:19:16', '61442-201', 7);
insert into prestamos (fecha_prestamo, fecha_devolucion_esperada, isbn, lector_id) values ('2023-02-10 06:20:01', '2023-04-11 08:25:41', '49348-845', 3);
insert into prestamos (fecha_prestamo, fecha_devolucion_esperada, isbn, lector_id) values ('2023-02-06 19:52:50', '2023-04-07 11:28:51', '0115-1331', 9);
insert into prestamos (fecha_prestamo, fecha_devolucion_esperada, isbn, lector_id) values ('2023-02-22 22:08:54', '2023-03-18 13:10:26', '52125-648', 4);
insert into prestamos (fecha_prestamo, fecha_devolucion_esperada, isbn, lector_id) values ('2023-02-08 14:23:26', '2023-03-27 19:09:33', '36987-2550', 3);
insert into prestamos (fecha_prestamo, fecha_devolucion_esperada, isbn, lector_id) values ('2023-02-10 11:05:39', '2023-04-03 16:14:36', '10733-357', 1);
insert into prestamos (fecha_prestamo, fecha_devolucion_esperada, isbn, lector_id) values ('2023-02-07 12:47:38', '2023-03-30 03:07:25', '59779-572', 4);
insert into prestamos (fecha_prestamo, fecha_devolucion_esperada, isbn, lector_id) values ('2023-02-21 07:12:55', '2023-04-10 15:40:52', '49967-166', 7);
insert into prestamos (fecha_prestamo, fecha_devolucion_esperada, isbn, lector_id) values ('2023-02-22 14:30:34', '2023-04-12 23:35:35', '66184-490', 4);

select * from prestamos;

